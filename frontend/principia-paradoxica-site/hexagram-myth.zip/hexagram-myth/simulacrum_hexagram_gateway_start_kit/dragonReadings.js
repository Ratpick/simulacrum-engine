// dragonReadings.js - Wilhelm translation for Hexagram 1, lines 1-6
export default [
  "Nine at the beginning means: Hidden dragon. Do not act. ...",
  "Nine in the second place means: Dragon appearing in the field. It furthers one to see the great man. ...",
  "Nine in the third place means: All day long the superior man is creatively active. At nightfall his mind is still beset with cares. Danger. No blame. ...",
  "Nine in the fourth place means: Wavering flight over the depths. No blame. ...",
  "Nine in the fifth place means: Flying dragon in the heavens. It furthers one to see the great man. ...",
  "Nine at the top means: Arrogant dragon will have cause to repent. ..."
];
